insert into clients( server_id,  client_unique_id,  client_nickname,  client_lastconnected, org_client_id)
 values(:server_id:, :client_unique_id*:, :client_nickname*:, :client_lastconnected:, :org_client_id*:)
[[[,(:server_id:, :client_unique_id*:, :client_nickname*:, :client_lastconnected:, :org_client_id*:) ]]] ;
