CREATE INDEX index_clients_uid ON clients (client_unique_id, server_id);
